# MASTER REPAIR PLAN — Secretary DesignLeaf CRM
## Kompletní rekonstrukce databázové synchronizace

**Verze:** 1.0  
**Datum:** 2. dubna 2026  
**Stav:** ⛔ SCHEMA DRIFT CRITICAL — vývoj zmražen do dokončení  
**Autor:** Claude AI pod vedením Marka Simy

---

## ROZHODNUTÍ PŘED ZAHÁJENÍM

### R1: Cílové schema
**Rozhodnutí:** Sjednotit vše do `crm` schema.  
**Důvod:** Dual schema (crm + public) je křehké — závisí na `SET search_path` při každém spojení. Jedna zapomenutá connection = celý systém spadne.

### R2: Source of truth
**Rozhodnutí:** Po opravě bude autoritou nový soubor `schema_v2.sql` v repozitáři.  
**Důvod:** Railway DB je aktuální realita, ale obsahuje drift. Nové schema vznikne jako MERGE reality + záměru.

### R3: Migration framework
**Rozhodnutí:** Zavést složku `migrations/` s číslovanými SQL soubory.  
**Důvod:** Runtime `CREATE TABLE IF NOT EXISTS` + `DO $$ ALTER` je nespolehlivé a neauditovatelné.

### R4: jobs.property_id
**Rozhodnutí:** Změnit na `BIGINT NULL` (nullable).  
**Důvod:** Ne každá zakázka má nemovitost (např. konzultace, údržba obecně).

### R5: tenant_id
**Rozhodnutí:** Přidat do VŠECH business tabulek, i když je teď single-tenant.  
**Důvod:** Blueprint to vyžaduje. Přidání později = bolestivá migrace.

---

## FÁZE 0: ZMRAZENÍ PROJEKTU

### Co je ZAKÁZÁNO:
- Nové feature
- Nové tabulky
- Nové endpointy
- Nové ALTER TABLE
- Změny v Models.kt nad rámec repair plánu

### Co je POVOLENO:
- Diagnostika
- Backup
- Oprava driftu dle tohoto plánu

---

## FÁZE 1: BACKUP A FORENZNÍ DŮKAZ

### 1.1 Backup Railway DB
Otevřít Railway Dashboard → PostgreSQL service → Data → Create Backup

### 1.2 Diagnostické SQL
Spustit v Railway Query Editor:

```sql
-- 1. Všechny tabulky a jejich schema
SELECT table_schema, table_name 
FROM information_schema.tables 
WHERE table_schema IN ('crm','public') 
AND table_type='BASE TABLE' 
ORDER BY 1,2;

-- 2. Kompletní sloupce všech tabulek
SELECT table_schema, table_name, column_name, data_type, 
       is_nullable, column_default, character_maximum_length
FROM information_schema.columns 
WHERE table_schema IN ('crm','public')
ORDER BY table_schema, table_name, ordinal_position;

-- 3. Primary keys
SELECT tc.table_schema, tc.table_name, kcu.column_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu 
  ON tc.constraint_name = kcu.constraint_name
WHERE tc.constraint_type = 'PRIMARY KEY'
AND tc.table_schema IN ('crm','public')
ORDER BY 1,2;

-- 4. Foreign keys
SELECT tc.table_schema, tc.table_name, kcu.column_name,
       ccu.table_schema AS ref_schema, ccu.table_name AS ref_table, 
       ccu.column_name AS ref_column
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu 
  ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage ccu 
  ON tc.constraint_name = ccu.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
AND tc.table_schema IN ('crm','public')
ORDER BY 1,2;

-- 5. Indexy
SELECT schemaname, tablename, indexname, indexdef
FROM pg_indexes 
WHERE schemaname IN ('crm','public')
ORDER BY 1,2,3;

-- 6. Unique constraints
SELECT tc.table_schema, tc.table_name, tc.constraint_name, 
       kcu.column_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu 
  ON tc.constraint_name = kcu.constraint_name
WHERE tc.constraint_type = 'UNIQUE'
AND tc.table_schema IN ('crm','public')
ORDER BY 1,2,3;

-- 7. Check constraints
SELECT table_schema, table_name, constraint_name, check_clause
FROM information_schema.check_constraints cc
JOIN information_schema.table_constraints tc USING (constraint_name)
WHERE tc.table_schema IN ('crm','public')
AND constraint_name NOT LIKE '%_not_null'
ORDER BY 1,2;
```

### 1.3 Výstup
Výsledky uložit do souboru `RAILWAY_DB_SNAPSHOT_2026-04-02.txt` v repozitáři.

---

## FÁZE 2: CÍLOVÉ UNIFIED SCHEMA

### 2.1 Princip
Jedna SQL definice, která popisuje CELOU databázi.
Žádné `IF NOT EXISTS`. Žádné `DO $$ ALTER`. Čisté `CREATE TABLE`.

### 2.2 Cílové tabulky (32)

#### Systémové (crm schema)
1. `tenants` — multi-tenant základ
2. `roles` — role systému
3. `permissions` — oprávnění
4. `role_permissions` — vazba role↔oprávnění
5. `users` — uživatelé
6. `audit_log` — auditní záznamy (trigger-based)

#### Klientské (crm schema)
7. `clients` — klienti (23+ sloupců dle schema.sql)
8. `client_notes` — poznámky ke klientům
9. `properties` — nemovitosti
10. `property_zones` — zóny nemovitostí

#### Obchodní (crm schema)
11. `leads` — poptávky (vč. contact_name, description atd.)
12. `quotes` — nabídky
13. `jobs` — zakázky (property_id NULLABLE)
14. `job_tasks` — úkoly zakázek (původní z schema.sql)
15. `job_notes` — poznámky k zakázkám

#### Úkolový systém (crm schema — přesunout z public)
16. `tasks` — kompletní úkoly (30+ sloupců)
17. `task_history` — historie změn úkolů

#### Finance (crm schema)
18. `invoices` — faktury
19. `waste_types` — typy odpadů
20. `waste_loads` — evidence odpadů

#### Komunikace (crm schema)
21. `communications` — log komunikace (vč. comm_type, job_id, notes)

#### Media (crm schema — přesunout z public)
22. `photos` — fotodokumentace

#### Work Reports (crm schema — přesunout z public)
23. `work_reports` — výkazy práce
24. `work_report_workers` — pracovníci ve výkazu
25. `work_report_entries` — položky práce
26. `work_report_materials` — materiál
27. `work_report_waste` — odpad ve výkazu

#### Voice (crm schema — přesunout z public)
28. `voice_sessions` — hlasové session
29. `pricing_rules` — ceníky

#### Audit & Timeline (crm schema — přesunout z public)
30. `activity_timeline` — časová osa aktivit

#### Budoucí (připravit strukturu)
31. `notifications` — notifikace (placeholder)
32. `system_settings` — systémové nastavení

### 2.3 Povinné sloupce na KAŽDÉ business tabulce
```
tenant_id INT NOT NULL DEFAULT 1
created_at TIMESTAMPTZ NOT NULL DEFAULT now()
updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
```

### 2.4 Povinné sloupce na editovatelných tabulkách
```
created_by BIGINT  (FK → users.id, nullable)
updated_by BIGINT  (FK → users.id, nullable)
```

### 2.5 Povinné sloupce na archivovatelných tabulkách
```
deleted_at TIMESTAMPTZ  (soft delete)
```

---

## FÁZE 3: REPAIR SQL

### 3.1 Postup vytvoření
Po obdržení výsledků diagnostiky z FÁZE 1:

1. Porovnat každou tabulku: realita vs. cíl
2. Pro KAŽDÝ rozdíl napsat konkrétní ALTER TABLE
3. Pro tabulky v `public` schema: `ALTER TABLE public.X SET SCHEMA crm`
4. Pro chybějící sloupce: `ALTER TABLE crm.X ADD COLUMN IF NOT EXISTS ...`
5. Pro NOT NULL které nemají smysl: `ALTER TABLE crm.X ALTER COLUMN Y DROP NOT NULL`
6. Pro chybějící FK: `ALTER TABLE crm.X ADD CONSTRAINT ...`
7. Pro chybějící indexy: `CREATE INDEX IF NOT EXISTS ...`
8. Pro tenant_id: přidat + nastavit default 1

### 3.2 Přesun tabulek do crm schema
```sql
-- Přesunout public tabulky do crm
ALTER TABLE public.tasks SET SCHEMA crm;
ALTER TABLE public.client_notes SET SCHEMA crm;
ALTER TABLE public.job_notes SET SCHEMA crm;
ALTER TABLE public.task_history SET SCHEMA crm;
ALTER TABLE public.activity_timeline SET SCHEMA crm;
ALTER TABLE public.photos SET SCHEMA crm;
ALTER TABLE public.work_reports SET SCHEMA crm;
ALTER TABLE public.work_report_workers SET SCHEMA crm;
ALTER TABLE public.work_report_entries SET SCHEMA crm;
ALTER TABLE public.work_report_materials SET SCHEMA crm;
ALTER TABLE public.work_report_waste SET SCHEMA crm;
ALTER TABLE public.voice_sessions SET SCHEMA crm;
ALTER TABLE public.pricing_rules SET SCHEMA crm;
```

### 3.3 Oprava jobs.property_id
```sql
ALTER TABLE crm.jobs ALTER COLUMN property_id DROP NOT NULL;
```

### 3.4 Doplnění tenant_id
```sql
-- Na každou tabulku která ho nemá:
ALTER TABLE crm.jobs ADD COLUMN IF NOT EXISTS tenant_id INT NOT NULL DEFAULT 1;
ALTER TABLE crm.leads ADD COLUMN IF NOT EXISTS tenant_id INT NOT NULL DEFAULT 1;
ALTER TABLE crm.invoices ADD COLUMN IF NOT EXISTS tenant_id INT NOT NULL DEFAULT 1;
ALTER TABLE crm.communications ADD COLUMN IF NOT EXISTS tenant_id INT NOT NULL DEFAULT 1;
ALTER TABLE crm.properties ADD COLUMN IF NOT EXISTS tenant_id INT NOT NULL DEFAULT 1;
ALTER TABLE crm.tasks ADD COLUMN IF NOT EXISTS tenant_id INT NOT NULL DEFAULT 1;
ALTER TABLE crm.client_notes ADD COLUMN IF NOT EXISTS tenant_id INT NOT NULL DEFAULT 1;
ALTER TABLE crm.job_notes ADD COLUMN IF NOT EXISTS tenant_id INT NOT NULL DEFAULT 1;
ALTER TABLE crm.task_history ADD COLUMN IF NOT EXISTS tenant_id INT NOT NULL DEFAULT 1;
ALTER TABLE crm.photos ADD COLUMN IF NOT EXISTS tenant_id INT NOT NULL DEFAULT 1;
ALTER TABLE crm.quotes ADD COLUMN IF NOT EXISTS tenant_id INT NOT NULL DEFAULT 1;
-- work_reports, voice_sessions, pricing_rules už mají
```

### 3.5 Doplnění chybějících sloupců do leads
```sql
ALTER TABLE crm.leads ADD COLUMN IF NOT EXISTS contact_name TEXT;
ALTER TABLE crm.leads ADD COLUMN IF NOT EXISTS contact_email TEXT;
ALTER TABLE crm.leads ADD COLUMN IF NOT EXISTS contact_phone TEXT;
ALTER TABLE crm.leads ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE crm.leads ADD COLUMN IF NOT EXISTS notes TEXT;
ALTER TABLE crm.leads ADD COLUMN IF NOT EXISTS job_id BIGINT;
```

### 3.6 Doplnění chybějících sloupců do communications
```sql
ALTER TABLE crm.communications ADD COLUMN IF NOT EXISTS comm_type TEXT DEFAULT 'telefon';
ALTER TABLE crm.communications ADD COLUMN IF NOT EXISTS job_id BIGINT;
ALTER TABLE crm.communications ADD COLUMN IF NOT EXISTS notes TEXT;
```

### 3.7 Doplnění do activity_timeline
```sql
ALTER TABLE crm.activity_timeline ADD COLUMN IF NOT EXISTS tenant_id INT DEFAULT 1;
ALTER TABLE crm.activity_timeline ADD COLUMN IF NOT EXISTS user_id_ref TEXT;
```

### 3.8 Tenants tabulka (nová)
```sql
CREATE TABLE IF NOT EXISTS crm.tenants (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO crm.tenants (name, slug) VALUES ('DesignLeaf', 'designleaf')
ON CONFLICT (slug) DO NOTHING;
```

---

## FÁZE 4: OPRAVA BACKENDU (main.py)

### 4.1 Odstranit EXTRA_TABLES_SQL z runtime
Po aplikaci repair SQL na Railway se EXTRA_TABLES_SQL stane zbytečný.
Nahradit ho POUZE kontrolou existence (bez CREATE):

```python
STARTUP_CHECK_SQL = """
SELECT COUNT(*) FROM information_schema.tables 
WHERE table_schema='crm' AND table_name='clients';
"""
```

### 4.2 Opravit init_pool()
Přidat `SET search_path` PŘED jakýkoli SQL příkaz (UŽ HOTOVO — aplikováno).

### 4.3 Opravit VŠECHNY INSERT INTO jobs
Radky 326, 609, 796 — zajistit že `property_id` je buď předán nebo NULL.

### 4.4 Projít KAŽDÝ endpoint
| Endpoint | Akce |
|----------|------|
| `POST /crm/clients` | Přidat tenant_id do INSERT |
| `POST /crm/jobs` | Přidat tenant_id, opravit property_id |
| `POST /crm/tasks` | Přidat tenant_id |
| `POST /crm/leads` | Přidat tenant_id |
| `POST /crm/invoices` | Přidat tenant_id |
| `POST /crm/communications` | Přidat tenant_id |
| `GET /crm/clients` | Přidat WHERE tenant_id=%s |
| `GET /crm/jobs` | Přidat WHERE j.tenant_id=%s |
| `GET /crm/tasks` | Přidat WHERE tenant_id=%s |
| `GET /crm/leads` | Přidat WHERE tenant_id=%s |
| Všechny voice endpointy | Ověřit tenant_id filtering |

### 4.5 Opravit log_activity
Zajistit že KAŽDÉ volání předává tenant_id a user_id:
```python
log_activity(conn, "entity", id, "action", "desc", 
             tenant_id=tenant_id, user_id=user_id)
```

### 4.6 Transakční bezpečnost
KAŽDÝ endpoint s write operací musí mít:
```python
try:
    ...
    conn.commit()
except HTTPException: 
    conn.rollback()
    raise
except Exception as e: 
    conn.rollback()
    raise HTTPException(500, str(e))
finally: 
    release_conn(conn)
```

---

## FÁZE 5: OPRAVA API KONTRAKTŮ

### 5.1 GET endpointy — SELECT *
Všechny GET endpointy MUSÍ vracet kompletní data z DB.
Žádné hardcoded seznamy sloupců (už částečně opraveno).

### 5.2 POST endpointy — přijímat všechna pole
`POST /crm/clients` musí umět přijmout a uložit VŠECHNA pole z clients tabulky.

### 5.3 PUT endpointy — editovat všechna pole
`PUT /crm/clients/{id}` musí umět editovat VŠECHNA editovatelná pole (už částečně opraveno — 20 polí).

---

## FÁZE 6: OPRAVA ANDROID MODELŮ

### 6.1 Models.kt
Musí 1:1 odpovídat JSON odpovědím serveru.
- Client: 23+ polí (UŽ OPRAVENO)
- Job: 12 polí vč. client_name z JOIN (UŽ OPRAVENO)  
- Lead: 13 polí bez phantom lead_name (UŽ OPRAVENO)
- Invoice: 8 polí vč. client_name z JOIN (UŽ OPRAVENO)
- Communication: 10 polí (UŽ OPRAVENO)
- Task: 30+ polí (beze změny)

### 6.2 SecretaryApi.kt
Musí mít endpoint pro KAŽDOU serverovou operaci.
Všechny Map parametry s `@JvmSuppressWildcards` (UŽ OPRAVENO).

### 6.3 UI karty
KAŽDÁ karta v CRM musí zobrazovat data z REÁLNÝCH DB sloupců:
- Client karta: jméno, kód, telefon, email, adresa, typ, stav
- Job karta: název, číslo, stav, klient, datum, adresa
- Lead karta: kontakt, zdroj, popis, stav, datum
- Invoice karta: číslo, klient, částka, stav, splatnost
- Communication karta: typ, směr, předmět, datum

### 6.4 Edit dialogy
KAŽDÝ edit dialog musí umožnit editaci VŠECH relevantních polí.

---

## FÁZE 7: ZAVEDENÍ MIGRATION DISCIPLÍNY

### 7.1 Struktura
```
server/
  migrations/
    000_initial_schema.sql      (= nové schema_v2.sql)
    001_repair_drift.sql        (= repair SQL z FÁZE 3)
    README.md                   (pravidla)
  main.py
  schema.sql                    (archivovat, nepoužívat)
```

### 7.2 Pravidla
1. Každá změna DB = nový soubor v `migrations/`
2. Soubory se pojmenovávají: `NNN_popis.sql`
3. Každý soubor se aplikuje ručně přes Railway Query Editor
4. Po aplikaci se zapíše do `migration_log` tabulky
5. `EXTRA_TABLES_SQL` v main.py se ODSTRANÍ
6. Runtime server NESMÍ měnit schema
7. `DO $$ EXCEPTION WHEN OTHERS THEN NULL` je ZAKÁZÁNO

### 7.3 Migration log tabulka
```sql
CREATE TABLE IF NOT EXISTS crm.migration_log (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    filename TEXT NOT NULL UNIQUE,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    applied_by TEXT DEFAULT 'manual'
);
```

---

## FÁZE 8: VERIFIKACE

### 8.1 End-to-end test
Po dokončení VŠECH fází:
1. Vytvořit klienta (POST /crm/clients) — ověřit všechna pole
2. Vytvořit zakázku (POST /crm/jobs) — ověřit bez property_id
3. Vytvořit úkol (POST /crm/tasks) — ověřit tenant_id
4. Spustit voice session — ověřit celý flow
5. Zobrazit v Android appce — ověřit že karty ukazují data
6. Editovat klienta — ověřit že se uloží všechna pole

### 8.2 Kontrolní SQL
```sql
-- Ověřit že ŽÁDNÁ tabulka nezůstala v public schema
SELECT table_name FROM information_schema.tables 
WHERE table_schema='public' AND table_type='BASE TABLE';
-- Očekávaný výsledek: PRÁZDNÝ

-- Ověřit tenant_id na všech business tabulkách
SELECT table_name, column_name FROM information_schema.columns
WHERE table_schema='crm' AND column_name='tenant_id'
ORDER BY table_name;
-- Očekávaný výsledek: 20+ tabulek
```

---

## POŘADÍ PRACÍ (CHRONOLOGICKÉ)

| Krok | Fáze | Akce | Kdo |
|------|------|------|-----|
| 1 | 0 | Zmrazit vývoj | Marek |
| 2 | 1.1 | Backup Railway DB | Marek (Railway Dashboard) |
| 3 | 1.2 | Spustit diagnostické SQL | Marek (Railway Query Editor) |
| 4 | 1.3 | Sdílet výsledky s Claudem | Marek |
| 5 | 2 | Vytvořit cílové schema_v2.sql | Claude |
| 6 | 3 | Vytvořit repair SQL | Claude |
| 7 | 3 | Aplikovat repair SQL na Railway | Marek (Query Editor) |
| 8 | 4 | Opravit main.py | Claude |
| 9 | 5 | Opravit API kontrakty | Claude |
| 10 | 6 | Opravit Models.kt + UI | Claude |
| 11 | 7 | Zavést migrations/ | Claude |
| 12 | 8 | End-to-end test | Marek |
| 13 | — | Git push server | Marek |
| 14 | — | Run appka | Marek |

---

## CO JE UŽ HOTOVO

| Položka | Stav |
|---------|------|
| Audit report | ✅ |
| init_pool() search_path fix | ✅ (aplikováno, čeká na push) |
| Models.kt — kompletní pole | ✅ (Client 23+, Job 12, Lead 13, Invoice 8) |
| SecretaryApi.kt — @JvmSuppressWildcards | ✅ |
| GET /crm/clients — SELECT * | ✅ |
| GET /crm/jobs — JOIN client_name | ✅ |
| GET /crm/invoices — JOIN client_name | ✅ |
| GET /crm/leads — všechna pole | ✅ |
| PUT /crm/clients — 20 polí | ✅ |
| Strings.kt — i18n 123 stringů | ✅ |

## CO ZBÝVÁ

| Položka | Blokováno |
|---------|-----------|
| Diagnostické SQL z Railway | Čeká na Marka |
| Repair SQL | Čeká na diagnostiku |
| Přesun tabulek do crm schema | Čeká na repair SQL |
| tenant_id na všech tabulkách | Čeká na repair SQL |
| Oprava INSERT INTO jobs | Čeká na rozhodnutí property_id |
| ClientsListTab UI | Čeká na stabilní data |
| EditClientDialog plný | Čeká na stabilní data |
| Odstranění EXTRA_TABLES_SQL | Čeká na repair SQL |
| migrations/ složka | Čeká na schema_v2.sql |

---

**KONEC DOKUMENTU. Další implementace zakázána do dokončení FÁZE 1 (diagnostika).**
**První akce: Marek pushne server (init_pool fix), pak spustí diagnostické SQL na Railway.**
