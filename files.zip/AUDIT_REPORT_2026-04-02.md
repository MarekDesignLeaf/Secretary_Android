# FORENZNI AUDIT REPORT — Secretary DesignLeaf CRM
**Datum:** 2. dubna 2026  
**Auditor:** Claude AI  
**Stav:** ⛔ SCHEMA DRIFT CRITICAL  

---

## 1. EXECUTIVE SUMMARY

**System NENI synchronni.** Existuje kriticky nesoulad mezi:
- `schema.sql` (puvodni tabulky v `crm` schema)
- `EXTRA_TABLES_SQL` v `main.py` (runtime tabulky v `public` schema)
- `ALTER TABLE` prikazy (pravdepodobne NEAPLIKOVANE kvuli schema path bugu)
- Android `Models.kt` (castecne synchronizovano)
- API endpointy (nektere pisi do neexistujicich sloupcu)

**Pocet kritickych nesouladu: 11**  
**Je bezpecne pokracovat ve vyvoji: NE** — oprava musí probehnout pred jakoukoli dalsi implementaci.

---

## 2. SOURCE OF TRUTH DECISION

**Autorita: Aktualni Railway PostgreSQL databaze.**

Zduvodneni:
- `schema.sql` byl spusten manualne pres Railway query editor (dle project memory)
- `EXTRA_TABLES_SQL` bezi pri kazdem startu serveru s `CREATE TABLE IF NOT EXISTS`
- `ALTER TABLE ... IF NOT EXISTS` bezi pri kazdem startu, ALE v jinem schema contextu
- **Zadny migration framework** — zadna migration table, zadna version history
- Jediny zpusob jak zjistit realny stav je dotaz primo do Railway DB

**NELZE provest z tohoto auditu**: Primy pristup do Railway PostgreSQL. Audit je zalozeny na analyze kodu. Pro uplnou jistotu je nutne spustit diagnostic SQL primo na Railway.

---

## 3. FULL DIFF REPORT

### ⛔ CRITICAL BUG #1: SCHEMA PATH DRIFT

**Pricina:** `init_pool()` (radek 144) vytvori connection pool a spusti `EXTRA_TABLES_SQL` BEZ nastaveni `search_path`. Defaultni search_path v PostgreSQL je `"$user", public`.

**Nasledek:**
- `CREATE TABLE IF NOT EXISTS tasks (...)` → vytvori `public.tasks` ✅
- `ALTER TABLE leads ADD COLUMN ...` → hleda `public.leads` → **leads je v `crm` schema** → TICHY FAIL (zachycen `EXCEPTION WHEN OTHERS THEN NULL`)
- `ALTER TABLE clients ADD COLUMN ...` → hleda `public.clients` → TICHY FAIL
- `ALTER TABLE users ADD COLUMN ...` → hleda `public.users` → TICHY FAIL
- `ALTER TABLE communications ADD COLUMN ...` → TICHY FAIL
- `ALTER TABLE activity_timeline ADD COLUMN ...` → tabulka je v `public`, takze TOHLE PROJDE

**Overeni:** `get_db_conn()` (radek 158) nastavuje `SET search_path TO crm, public` na kazdou connection. Takze API dotazy najdou tabulky spravne. Ale `init_pool()` toto NEDELA.

**Potencialne neaplikovane ALTER:**
| ALTER | Cilova tabulka | Schema | Stav |
|-------|---------------|--------|------|
| `ALTER TABLE leads ADD COLUMN contact_name` | crm.leads | crm | ❌ PRAVDEPODOBNE NEAPLIKOVANO |
| `ALTER TABLE leads ADD COLUMN contact_email` | crm.leads | crm | ❌ |
| `ALTER TABLE leads ADD COLUMN contact_phone` | crm.leads | crm | ❌ |
| `ALTER TABLE leads ADD COLUMN description` | crm.leads | crm | ❌ |
| `ALTER TABLE leads ADD COLUMN notes` | crm.leads | crm | ❌ |
| `ALTER TABLE leads ADD COLUMN client_id` | crm.leads | crm | ⚠️ uz existuje v schema.sql |
| `ALTER TABLE leads ADD COLUMN job_id` | crm.leads | crm | ❌ |
| `ALTER TABLE leads ADD COLUMN updated_at` | crm.leads | crm | ⚠️ uz existuje v schema.sql |
| `ALTER TABLE communications ADD COLUMN comm_type` | crm.communications | crm | ❌ |
| `ALTER TABLE communications ADD COLUMN job_id` | crm.communications | crm | ❌ |
| `ALTER TABLE communications ADD COLUMN notes` | crm.communications | crm | ❌ |
| `ALTER TABLE users ADD COLUMN tenant_id` | crm.users | crm | ❌ |
| `ALTER TABLE users ADD COLUMN display_name` | crm.users | crm | ❌ (display_name uz existuje v schema.sql) |
| `ALTER TABLE users ADD COLUMN deleted_at` | crm.users | crm | ⚠️ uz existuje v schema.sql |
| `ALTER TABLE clients ADD COLUMN tenant_id` | crm.clients | crm | ❌ |
| `ALTER TABLE clients ADD COLUMN deleted_at` | crm.clients | crm | ⚠️ uz existuje v schema.sql |
| `ALTER TABLE activity_timeline ADD COLUMN tenant_id` | public.activity_timeline | public | ✅ PROJDE |
| `ALTER TABLE activity_timeline ADD COLUMN user_id_ref` | public.activity_timeline | public | ✅ PROJDE |

---

### ⛔ CRITICAL BUG #2: JOBS INSERT MISSING NOT NULL COLUMNS

**Schema.sql definice:**
```sql
jobs.client_id bigint NOT NULL
jobs.property_id bigint NOT NULL
```

**Endpointy ktere PORUSUJI NOT NULL:**

| Radek | Endpoint | Chybi |
|-------|----------|-------|
| 326 | GPT tool `create_job` | `client_id` + `property_id` |
| 796 | `POST /crm/leads/{id}/convert-to-job` | `property_id` |

**Nasledek:** INSERT selze s `null value in column "property_id" violates not-null constraint`. Toto zpusobuje 500 errory pri vytvareni zakazek.

---

### ⛔ CRITICAL BUG #3: DUAL SCHEMA ARCHITECTURE

**Distribuce tabulek:**

| Schema | Tabulky |
|--------|---------|
| `crm` | audit_log, roles, permissions, users, role_permissions, clients, properties, property_zones, leads, quotes, jobs, job_tasks, waste_types, waste_loads, invoices, communications |
| `public` | tasks, client_notes, job_notes, task_history, activity_timeline, photos, work_reports, work_report_workers, work_report_entries, work_report_materials, work_report_waste, voice_sessions, pricing_rules |

**Riziko:** Pokud se zmeni `get_db_conn()` nebo se zapomene `SET search_path`, VSECHNY dotazy do `crm` tabulek selzou.

---

### TABULKA: CLIENTS

| Sloupec | schema.sql | EXTRA/ALTER | Android Model | API GET | API INSERT | API UPDATE |
|---------|-----------|-------------|---------------|---------|------------|------------|
| id | BIGINT PK | — | Long ✅ | SELECT * ✅ | RETURNING ✅ | — |
| client_code | TEXT NOT NULL | — | String? ✅ | ✅ | ✅ | ❌ ne |
| client_type | TEXT NOT NULL | — | String? ✅ | ✅ | ✅ | ❌ ne |
| title | TEXT | — | String? ✅ | ✅ | ❌ ne | ❌ ne |
| first_name | TEXT | — | String? ✅ | ✅ | ❌ ne | ❌ ne |
| last_name | TEXT | — | String? ✅ | ✅ | ❌ ne | ❌ ne |
| display_name | TEXT NOT NULL | — | String ✅ | ✅ | ✅ | ✅ |
| company_name | TEXT | — | String? ✅ | ✅ | ❌ ne | ❌ ne |
| company_registration_no | TEXT | — | String? ✅ | ✅ | ❌ ne | ❌ ne |
| vat_no | TEXT | — | String? ✅ | ✅ | ❌ ne | ❌ ne |
| phone_primary | TEXT | — | String? ✅ | ✅ | ✅ | ✅ |
| phone_secondary | TEXT | — | String? ✅ | ✅ | ❌ ne | ❌ ne |
| email_primary | TEXT | — | String? ✅ | ✅ | ✅ | ✅ |
| email_secondary | TEXT | — | String? ✅ | ✅ | ❌ ne | ❌ ne |
| website | TEXT | — | String? ✅ | ✅ | ❌ ne | ❌ ne |
| preferred_contact_method | TEXT NOT NULL DEFAULT 'email' | — | String? ✅ | ✅ | ❌ default OK | ❌ ne |
| billing_address_line1 | TEXT | — | String? ✅ | ✅ | ❌ ne | ✅ |
| billing_city | TEXT | — | String? ✅ | ✅ | ❌ ne | ✅ |
| billing_postcode | TEXT | — | String? ✅ | ✅ | ❌ ne | ✅ |
| billing_country | TEXT NOT NULL DEFAULT 'GB' | — | String? ✅ | ✅ | ❌ default OK | ❌ ne |
| status | TEXT NOT NULL DEFAULT 'active' | — | String? ✅ | ✅ | ✅ | ✅ |
| is_commercial | BOOLEAN NOT NULL DEFAULT false | — | Boolean ✅ | ✅ | ❌ ne | ✅ (nove) |
| created_at | TIMESTAMPTZ | — | String? ✅ | ✅ | auto | — |
| updated_at | TIMESTAMPTZ | — | String? ✅ | ✅ | auto | auto |
| deleted_at | TIMESTAMPTZ | — | ❌ v modelu chybi | ✅ | — | — |
| created_by_user_id | BIGINT | — | ❌ v modelu chybi | ✅ | ❌ ne | — |
| tenant_id | ❌ neni v schema | ALTER ❌ mozna neaplikovano | Int? ✅ | ✅ pokud existuje | ❌ ne | — |

---

### TABULKA: JOBS

| Sloupec | schema.sql | Android Model | API GET | API INSERT |
|---------|-----------|---------------|---------|------------|
| id | BIGINT PK | Long ✅ | ✅ | RETURNING |
| job_number | TEXT NOT NULL | String? ✅ | ✅ | ✅ |
| client_id | BIGINT **NOT NULL** | Long? ✅ | ✅ | ⛔ CHYBI na radku 326 |
| property_id | BIGINT **NOT NULL** | Long? ✅ | ✅ | ⛔ CHYBI na radcich 326, 796 |
| quote_id | BIGINT | Long? ✅ | ✅ | ❌ nikdy nevkladano |
| job_title | TEXT NOT NULL | String ✅ | ✅ | ✅ |
| job_status | TEXT NOT NULL | String ✅ | ✅ | ✅ |
| start_date_planned | DATE | String? ✅ | ✅ (::text) | ✅ |
| client_name | ❌ NEEXISTUJE V DB | String? ✅ | ✅ (JOIN) | — |
| property_address | ❌ NEEXISTUJE V DB | String? ✅ | ❌ ne | — |

---

### TABULKA: LEADS

| Sloupec | schema.sql | ALTER | Android Model | API GET |
|---------|-----------|-------|---------------|---------|
| id | BIGINT PK | — | Long ✅ | ✅ |
| lead_code | TEXT NOT NULL | — | String? ✅ | ✅ |
| client_id | BIGINT | — | Long? ✅ | ✅ |
| lead_source | TEXT NOT NULL | — | String? ✅ | ✅ |
| status | TEXT NOT NULL | — | String ✅ | ✅ |
| received_at | TIMESTAMPTZ | — | String? ✅ | ✅ |
| contact_name | ❌ neni v schema | ALTER ❌ mozna ne | String? ✅ | ✅ (ale sloupec mozna neexistuje!) |
| contact_email | ❌ | ALTER ❌ mozna ne | String? ✅ | ✅ (ale...) |
| contact_phone | ❌ | ALTER ❌ mozna ne | String? ✅ | ✅ (ale...) |
| description | ❌ | ALTER ❌ mozna ne | String? ✅ | ✅ (ale...) |
| notes | ❌ | ALTER ❌ mozna ne | String? ✅ | ✅ (ale...) |
| job_id | ❌ | ALTER ❌ mozna ne | Long? ✅ | ✅ (ale...) |

---

### TABULKA: COMMUNICATIONS

| Sloupec | schema.sql | ALTER | Android Model |
|---------|-----------|-------|---------------|
| comm_type | ❌ | ALTER ❌ mozna ne | String? ✅ |
| job_id | ❌ | ALTER ❌ mozna ne | Long? ✅ |
| notes | ❌ | ALTER ❌ mozna ne | String? ✅ |

---

### TABULKA: USERS

| Sloupec | schema.sql | ALTER | Pouziti v kodu |
|---------|-----------|-------|----------------|
| tenant_id | ❌ | ALTER ❌ mozna ne | voice_session hleda `users.tenant_id` |
| display_name | ✅ uz existuje | ALTER (redundantni) | ✅ |
| deleted_at | ✅ uz existuje | ALTER (redundantni) | ✅ |

---

## 4. CRITICAL FAILURES

### ⛔ CF-1: ALTER TABLE statements pravdepodobne neaplikovane
**Nasledek:** Dotazy do `leads.contact_name`, `communications.comm_type`, `clients.tenant_id` mohou zpusobit `column does not exist` → 500 error
**Dukaz:** Voice session input vracelo 500 pri `WHERE deleted_at IS NULL` (clients.deleted_at pridano ALTERem)

### ⛔ CF-2: jobs.property_id NOT NULL ale INSERT ho nepredava
**Nasledek:** Vytvareni zakazek hlasem (radek 326) a konverze leadu (radek 796) vzdy selze
**Dukaz:** INSERT do `jobs` bez `property_id` → NOT NULL violation → 500

### ⛔ CF-3: Dve schema bez explicitni kontroly
**Nasledek:** Pokud `get_db_conn()` prestane nastavovat `search_path`, VSECHNO spadne
**Riziko:** Vysoke — jedina zmena v connection handleru znici cely system

### ⚠️ CF-4: Zadny tenant_id na 16 z 28 tabulek
**Nasledek:** Multi-tenant izolace nefunkční. Blueprint vyzaduje tenant_id vsude.
**Tabulky bez tenant_id:** jobs, leads, invoices, communications, properties, tasks, client_notes, job_notes, task_history, photos, roles, permissions, role_permissions, quotes, waste_types, waste_loads

### ⚠️ CF-5: Zadne foreign keys v EXTRA_TABLES_SQL
**Nasledek:** Orphaned records — tasks odkazujici na smazane klienty, work_reports na neexistujici joby

### ⚠️ CF-6: Zadna migration framework
**Nasledek:** Neexistuje spolehlivy zpusob jak zjistit, jaka migrace byla posledni, co bylo aplikovano, co ne

---

## 5. REPAIR PLAN

### KROK 0: DIAGNOSTIKA (NUTNA PRED CIMKOLI)
Spustit na Railway PostgreSQL:
```sql
-- Zjisti vsechny tabulky a jejich schema
SELECT table_schema, table_name FROM information_schema.tables 
WHERE table_schema IN ('crm','public') AND table_type='BASE TABLE' ORDER BY 1,2;

-- Zjisti sloupce clients tabulky
SELECT column_name, data_type, is_nullable, column_default 
FROM information_schema.columns WHERE table_name='clients' ORDER BY ordinal_position;

-- Zjisti zda existuje clients.tenant_id
SELECT column_name FROM information_schema.columns 
WHERE table_name='clients' AND column_name='tenant_id';

-- Zjisti zda existuje leads.contact_name
SELECT column_name FROM information_schema.columns 
WHERE table_name='leads' AND column_name='contact_name';

-- Zjisti zda existuje communications.comm_type
SELECT column_name FROM information_schema.columns 
WHERE table_name='communications' AND column_name='comm_type';
```

### KROK 1: OPRAVA init_pool() — PRIDAT search_path
```python
def init_pool():
    global db_pool
    try:
        db_pool = pool.ThreadedConnectionPool(2, 10, **DB_CONFIG)
        conn = db_pool.getconn()
        with conn.cursor() as cur:
            cur.execute("SET search_path TO crm, public")  # <-- PRIDEJ TOTO
            cur.execute(EXTRA_TABLES_SQL)
            conn.commit()
        db_pool.putconn(conn)
    except Exception as e: print(f"DB pool FAIL: {e}")
```

### KROK 2: OPRAVA jobs INSERT — property_id
Buď:
a) Zmenit `jobs.property_id` na `BIGINT NULL` (ALTER TABLE)
b) Nebo vzdy predavat property_id v INSERT

Doporuceni: **Zmenit na NULL** — ne kazda zakazka ma nemovitost.

### KROK 3: REPAIR MIGRACE
Po diagnostice z KROKU 0 vytvorit jednu opravnou migraci ktera:
- Prida chybejici sloupce do spravneho schema
- Prida tenant_id kde chybi
- Prida indexy
- Zmeni property_id na nullable

### KROK 4: KOD FIX
- Aktualizovat vsechny INSERT INTO jobs
- Aktualizovat Models.kt (uz castecne hotovo)
- Aktualizovat API endpointy (uz castecne hotovo)

### KROK 5: TEST
- Otestovat kazdy endpoint
- Overit voice session kompletne
- Overit ze vsechny karty zobrazuji data

---

## 6. SAFE NEXT ACTION

**PRVNI BEZPECNY KROK:**

Pridej `SET search_path TO crm, public` do `init_pool()` PRED `EXTRA_TABLES_SQL`. Toto je jednoradkova zmena na radku ~150 v `main.py`. Po git push na Railway se vsechny ALTER TABLE prikazy spravne aplikuji pri pristim restartu serveru.

**DRUHY KROK:**

Spust diagnosticke SQL dotazy z KROKU 0 na Railway PostgreSQL pres Railway query editor abys zjistil, ktere ALTER TABLE prikazy se aplikovaly a ktere ne.

**AZ POTOM** pokracuj s dalsim vyvojem.

---

## APPENDIX: KOMPLETNI SEZNAM TABULEK

| # | Tabulka | Schema | Vytvorena | tenant_id | FK |
|---|---------|--------|-----------|-----------|-----|
| 1 | audit_log | crm | schema.sql | ❌ | ❌ |
| 2 | roles | crm | schema.sql | ❌ | ❌ |
| 3 | permissions | crm | schema.sql | ❌ | ❌ |
| 4 | users | crm | schema.sql | ❌ ALTER? | FK roles |
| 5 | role_permissions | crm | schema.sql | ❌ | FK roles, permissions |
| 6 | clients | crm | schema.sql | ❌ ALTER? | ❌ |
| 7 | properties | crm | schema.sql | ❌ | FK clients |
| 8 | property_zones | crm | schema.sql | ❌ | FK properties |
| 9 | leads | crm | schema.sql | ❌ | ❌ |
| 10 | quotes | crm | schema.sql | ❌ | ❌ |
| 11 | jobs | crm | schema.sql | ❌ | ❌ |
| 12 | job_tasks | crm | schema.sql | ❌ | FK jobs |
| 13 | waste_types | crm | schema.sql | ❌ | ❌ |
| 14 | waste_loads | crm | schema.sql | ❌ | FK jobs |
| 15 | invoices | crm | schema.sql | ❌ | ❌ |
| 16 | communications | crm | schema.sql | ❌ | ❌ |
| 17 | tasks | public | EXTRA_TABLES | ❌ | ❌ |
| 18 | client_notes | public | EXTRA_TABLES | ❌ | ❌ |
| 19 | job_notes | public | EXTRA_TABLES | ❌ | ❌ |
| 20 | task_history | public | EXTRA_TABLES | ❌ | ❌ |
| 21 | activity_timeline | public | EXTRA_TABLES | ✅ ALTER | ❌ |
| 22 | photos | public | EXTRA_TABLES | ❌ | ❌ |
| 23 | work_reports | public | EXTRA_TABLES | ✅ | ❌ |
| 24 | work_report_workers | public | EXTRA_TABLES | ❌ | ❌ |
| 25 | work_report_entries | public | EXTRA_TABLES | ❌ | ❌ |
| 26 | work_report_materials | public | EXTRA_TABLES | ❌ | ❌ |
| 27 | work_report_waste | public | EXTRA_TABLES | ❌ | ❌ |
| 28 | voice_sessions | public | EXTRA_TABLES | ✅ | ❌ |
| 29 | pricing_rules | public | EXTRA_TABLES | ✅ | ❌ |

---

**KONEC AUDITU. Dalsi implementace ZAKAZANA do dokonceni KROKU 0 a 1 z repair planu.**
